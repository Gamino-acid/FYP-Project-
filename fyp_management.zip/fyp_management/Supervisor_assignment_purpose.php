<?php
date_default_timezone_set('Asia/Kuala_Lumpur');
include("connect.php");

// --- 处理表单提交 ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['ajax_propose_assignment'])) {
    header('Content-Type: application/json');
    $auth_user_id = $_POST['auth_user_id'] ?? null;

    // 1. 获取 Staff ID
    $my_staff_id = "";
    $stmt = $conn->prepare("SELECT fyp_staffid FROM supervisor WHERE fyp_userid = ?");
    $stmt->bind_param("i", $auth_user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) $my_staff_id = $row['fyp_staffid'];
    $stmt->close();

    if (empty($my_staff_id)) {
        echo json_encode(['status' => 'error', 'message' => 'Staff ID not found.']);
        exit;
    }

    // 2. 获取表单数据
    $a_title = $_POST['assignment_title'];
    $a_desc = $_POST['assignment_description'];
    $a_deadline = $_POST['deadline'];
    $a_type = $_POST['assignment_type']; 
    $weightage = intval($_POST['weightage']); // 确保转为数字
    $a_status = 'Active';
    $date_now = date('Y-m-d H:i:s');

    // 3. 处理多选目标 (Array)
    $targets_to_insert = [];
    if (isset($_POST['target_selection']) && is_array($_POST['target_selection'])) {
        $targets_to_insert = $_POST['target_selection'];
    } elseif (isset($_POST['target_selection']) && !empty($_POST['target_selection'])) {
        //以此防备单选的情况
        $targets_to_insert[] = $_POST['target_selection'];
    }

    if (empty($targets_to_insert)) {
        echo json_encode(['status' => 'error', 'message' => 'Please select at least one target (Student or Group).']);
        exit;
    }

    // --- [新增逻辑 START] 3.5 检查 Weightage 是否超过 100% ---
    // 在插入之前，先检查选中的每个目标，如果加上这次的分数会超过 100，就报错拦截
    $errors = [];
    
    // 准备查询：计算该目标目前已有的总分 (从 assignment 表查询 fyp_target_id)
    $sql_check = "SELECT SUM(fyp_weightage) as total_score FROM assignment WHERE fyp_target_id = ?";
    
    if ($stmt_check = $conn->prepare($sql_check)) {
        foreach ($targets_to_insert as $single_target_id) {
            $stmt_check->bind_param("s", $single_target_id);
            $stmt_check->execute();
            $res_check = $stmt_check->get_result();
            $row_check = $res_check->fetch_assoc();
            
            // 获取当前已有的分数（如果没有记录则为0）
            $current_total = $row_check['total_score'] ? intval($row_check['total_score']) : 0;
            $new_total = $current_total + $weightage;

            // 逻辑判断：如果当前总分 + 新分数 > 100，则记录错误
            if ($new_total > 100) {
                // $single_target_id 可能是 StudentID 或 GroupID
                $errors[] = "Target ID [$single_target_id]: Current total is $current_total%. Adding $weightage% would equal $new_total%, which exceeds 100%.";
            }
        }
        $stmt_check->close();
    }

    // 如果发现有错误（即有人会超过100分），直接停止并返回错误信息
    if (!empty($errors)) {
        echo json_encode([
            'status' => 'error', 
            'message' => "Validation Error: Total weightage limit exceeded!\n\n" . implode("\n", $errors)
        ]);
        exit; // 终止程序，不进行下面的插入操作
    }
    // --- [新增逻辑 END] ---


    // 4. 循环插入数据库
    $sql_insert = "INSERT INTO assignment (fyp_staffid, fyp_title, fyp_description, fyp_deadline, fyp_weightage, fyp_assignment_type, fyp_status, fyp_datecreated, fyp_target_id) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    if ($stmt_insert = $conn->prepare($sql_insert)) {
        $success_count = 0;
        
        foreach ($targets_to_insert as $single_target_id) {
            // 绑定参数: 最后一个参数是当前循环的 target ID
            $stmt_insert->bind_param("ssssissss", $my_staff_id, $a_title, $a_desc, $a_deadline, $weightage, $a_type, $a_status, $date_now, $single_target_id);
            if ($stmt_insert->execute()) {
                $success_count++;
            }
        }
        $stmt_insert->close();

        if ($success_count > 0) {
            echo json_encode(['status' => 'success', 'message' => "Assignment successfully published to $success_count target(s)!"]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Database Error: No records inserted.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'SQL Prepare Error: ' . $conn->error]);
    }
    exit;
}

// --- 页面加载逻辑 ---
$auth_user_id = $_GET['auth_user_id'] ?? null;
$current_page = 'propose_assignment'; 

if (!$auth_user_id) { header("location: login.php"); exit; }

$user_name = "Supervisor"; 
$user_avatar = "image/user.png"; 
$my_staff_id = ""; 
$my_groups = [];      
$my_individuals = []; 

if (isset($conn)) {
    // 获取 Supervisor 信息
    $stmt = $conn->prepare("SELECT * FROM supervisor WHERE fyp_userid = ?");
    $stmt->bind_param("i", $auth_user_id); $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $my_staff_id = $row['fyp_staffid'];
        if (!empty($row['fyp_name'])) $user_name = $row['fyp_name'];
        if (!empty($row['fyp_profileimg'])) $user_avatar = $row['fyp_profileimg'];
    }
    $stmt->close();

    // 获取该 Supervisor 下所有的学生和小组信息
    if (!empty($my_staff_id)) {
        $sql_my_students = "SELECT s.fyp_studid, s.fyp_studname, s.fyp_group 
                            FROM fyp_registration r
                            JOIN student s ON r.fyp_studid = s.fyp_studid
                            WHERE r.fyp_staffid = ? AND (r.fyp_archive_status = 'Active' OR r.fyp_archive_status IS NULL)"; 
        if ($stmt = $conn->prepare($sql_my_students)) {
            $stmt->bind_param("s", $my_staff_id); $stmt->execute();
            $res = $stmt->get_result();
            while ($row = $res->fetch_assoc()) {
                // 1. 收集 Individual
                if ($row['fyp_group'] == 'Individual') {
                    $my_individuals[$row['fyp_studid']] = $row['fyp_studname'];
                } else {
                    // 2. 收集 Group (尝试找 Leader 或 Member 所在的组)
                    $g_sql = "SELECT group_id, group_name FROM student_group WHERE leader_id = '" . $row['fyp_studid'] . "' LIMIT 1";
                    $g_res = $conn->query($g_sql);
                    if ($g_row = $g_res->fetch_assoc()) {
                        $my_groups[$g_row['group_id']] = $g_row['group_name'];
                    } else {
                        $m_sql = "SELECT g.group_id, g.group_name FROM group_request gr JOIN student_group g ON gr.group_id = g.group_id WHERE gr.invitee_id = '" . $row['fyp_studid'] . "' AND gr.request_status = 'Accepted' LIMIT 1";
                        $m_res = $conn->query($m_sql);
                        if ($m_row = $m_res->fetch_assoc()) $my_groups[$m_row['group_id']] = $m_row['group_name'];
                    }
                }
            }
            $stmt->close();
        }
    }
}

$menu_items = [
    'dashboard' => ['name' => 'Dashboard', 'icon' => 'fa-home', 'link' => 'Supervisor_mainpage.php?page=dashboard'],
    'profile'   => ['name' => 'My Profile', 'icon' => 'fa-user', 'link' => 'supervisor_profile.php'],
    'students'  => [
        'name' => 'My Students', 
        'icon' => 'fa-users',
        'sub_items' => [
            'project_requests' => ['name' => 'Project Requests', 'icon' => 'fa-envelope-open-text', 'link' => 'Supervisor_projectreq.php'],
            'student_list'     => ['name' => 'Student List', 'icon' => 'fa-list', 'link' => 'Supervisor_student_list.php'],
        ]
    ],
    'fyp_project' => [
        'name' => 'FYP Project',
        'icon' => 'fa-project-diagram',
        'sub_items' => [
            'propose_project' => ['name' => 'Propose Project', 'icon' => 'fa-plus-circle', 'link' => 'supervisor_purpose.php'],
            'my_projects'     => ['name' => 'My Projects', 'icon' => 'fa-folder-open', 'link' => 'Supervisor_manage_project.php'],
            'propose_assignment' => ['name' => 'Propose Assignment', 'icon' => 'fa-tasks', 'link' => 'supervisor_assignment_purpose.php'],
        ]
    ],
    'grading' => [
        'name' => 'Assessment',
        'icon' => 'fa-marker',
        'sub_items' => [
            'grade_assignment' => ['name' => 'Grade Assignments', 'icon' => 'fa-check-square', 'link' => 'Supervisor_assignment_grade.php'],
            'grade_mod' => ['name' => 'Moderator Grading', 'icon' => 'fa-gavel', 'link' => 'Moderator_assignment_grade.php'],
        ]
    ],
    'announcement' => [
        'name' => 'Announcement',
        'icon' => 'fa-bullhorn',
        'sub_items' => [
            'post_announcement' => ['name' => 'Post Announcement', 'icon' => 'fa-pen-square', 'link' => 'supervisor_announcement.php'],
            'view_announcements' => ['name' => 'View History', 'icon' => 'fa-history', 'link' => 'Supervisor_announcement_view.php'],
        ]
    ],
    'schedule'  => ['name' => 'My Schedule', 'icon' => 'fa-calendar-alt', 'link' => 'supervisor_meeting.php'],
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Propose Assignment</title>
    <link rel="icon" type="image/png" href="image/ladybug.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');
        
        :root {
            --primary-color: #0056b3;
            --primary-hover: #004494;
            --bg-color: #f4f6f9;
            --card-bg: #ffffff;
            --text-color: #333;
            --secondary-color: #f8f9fa;
            --sidebar-bg: #004085; 
            --sidebar-hover: #003366;
            --sidebar-text: #e0e0e0;
            --card-shadow: 0 4px 6px rgba(0,0,0,0.05);
            --border-color: #e0e0e0;
            --slot-bg: #f8f9fa;
        }

        .dark-mode {
            --primary-color: #4da3ff;
            --primary-hover: #0069d9;
            --bg-color: #121212;
            --card-bg: #1e1e1e;
            --text-color: #e0e0e0;
            --text-secondary: #a0a0a0;
            --sidebar-bg: #0d1117;
            --sidebar-hover: #161b22;
            --sidebar-text: #c9d1d9;
            --card-shadow: 0 4px 6px rgba(0,0,0,0.3);
            --border-color: #333;
            --slot-bg: #2d2d2d;
        }

        body { font-family: 'Poppins', sans-serif; margin: 0; background-color: var(--bg-color); min-height: 100vh; display: flex; overflow-x: hidden; transition: background-color 0.3s, color 0.3s; }

        .main-menu { background: var(--sidebar-bg); border-right: 1px solid rgba(255,255,255,0.1); position: fixed; top: 0; bottom: 0; height: 100%; left: 0; width: 60px; overflow-y: auto; overflow-x: hidden; transition: width .05s linear; z-index: 1000; box-shadow: 2px 0 5px rgba(0,0,0,0.1); }
        .main-menu:hover, nav.main-menu.expanded { width: 250px; }
        .main-menu > ul { margin: 7px 0; padding: 0; list-style: none; }
        .main-menu li { position: relative; display: block; width: 250px; }
        .main-menu li > a { position: relative; display: table; border-collapse: collapse; border-spacing: 0; color: var(--sidebar-text); font-size: 14px; text-decoration: none; transition: all .1s linear; width: 100%; }
        .main-menu .nav-icon { position: relative; display: table-cell; width: 60px; height: 46px; text-align: center; vertical-align: middle; font-size: 18px; }
        .main-menu .nav-text { position: relative; display: table-cell; vertical-align: middle; width: 190px; padding-left: 10px; white-space: nowrap; }
        .main-menu li:hover > a, nav.main-menu li.active > a, .menu-item.open > a { color: #fff; background-color: var(--sidebar-hover); border-left: 4px solid #fff; }
        .main-menu > ul.logout { position: absolute; left: 0; bottom: 0; width: 100%; }
        .dropdown-arrow { position: absolute; right: 15px; top: 50%; transform: translateY(-50%); transition: transform 0.3s; font-size: 12px; }
        .menu-item.open .dropdown-arrow { transform: translateY(-50%) rotate(180deg); }
        .submenu { list-style: none; padding: 0; margin: 0; background-color: rgba(0,0,0,0.2); max-height: 0; overflow: hidden; transition: max-height 0.3s ease-out; }
        .menu-item.open .submenu { max-height: 500px; transition: max-height 0.5s ease-in; }
        .submenu li > a { padding-left: 70px !important; font-size: 13px; height: 40px; }

        .main-content-wrapper { margin-left: 60px; flex: 1; padding: 20px; width: calc(100% - 60px); transition: margin-left .05s linear; }

        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; background: var(--card-bg); padding: 20px; border-radius: 12px; box-shadow: var(--card-shadow); transition: background 0.3s; }
        .welcome-text h1 { margin: 0; font-size: 24px; color: var(--primary-color); font-weight: 600; }
        .welcome-text p { margin: 5px 0 0; color: var(--text-color); font-size: 14px; opacity: 0.8; }
        .logo-section { display: flex; align-items: center; gap: 12px; }
        .logo-img { height: 40px; width: auto; background: white; padding: 2px; border-radius: 6px; }
        .system-title { font-size: 20px; font-weight: 600; color: var(--primary-color); letter-spacing: 0.5px; }

        .user-section { display: flex; align-items: center; gap: 10px; }
        .user-badge { font-size: 13px; color: var(--text-secondary); background: var(--slot-bg); padding: 5px 10px; border-radius: 20px; }
        .user-avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; }
        .user-avatar-placeholder { width: 40px; height: 40px; border-radius: 50%; background: #0056b3; color: white; display: flex; align-items: center; justify-content: center; font-weight: bold; }

        .form-card { background: var(--card-bg); padding: 30px; border-radius: 12px; box-shadow: var(--card-shadow); transition: background 0.3s; }
        .section-title { border-bottom: 2px solid var(--border-color); padding-bottom: 15px; margin-bottom: 25px; }
        .section-title h2 { margin: 0; color: var(--primary-color); font-size: 18px; display: flex; align-items: center; gap: 10px; }

        .form-row { display: flex; gap: 20px; }
        .form-group { margin-bottom: 20px; flex: 1; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 500; color: var(--text-color); font-size: 14px; opacity: 0.9; }
        .form-control { width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: 6px; font-size: 14px; box-sizing: border-box; transition: border 0.3s; font-family: inherit; background: var(--card-bg); color: var(--text-color); }
        .form-control:focus { border-color: var(--primary-color); outline: none; }
        textarea.form-control { resize: vertical; min-height: 120px; }

        .info-note { background-color: #e3effd; padding: 15px; border-radius: 8px; color: #0056b3; font-size: 13px; margin-bottom: 25px; border-left: 4px solid #0056b3; line-height: 1.5; }
        .btn-submit { background-color: var(--primary-color); color: white; border: none; padding: 12px 30px; border-radius: 6px; font-weight: 600; cursor: pointer; transition: background 0.2s; display: inline-flex; align-items: center; gap: 8px; font-size: 15px; }
        .btn-submit:hover { background-color: var(--primary-hover); }
        .btn-submit.loading { opacity: 0.7; pointer-events: none; }
        
        .target-select-container { display: none; margin-top: 10px; }

        /* --- 多选框样式 --- */
        .checkbox-group-container {
            border: 1px solid var(--border-color);
            border-radius: 6px;
            padding: 12px;
            background: var(--card-bg);
            max-height: 250px;
            overflow-y: auto;
        }
        .checkbox-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 10px;
            padding: 6px;
            border-radius: 4px;
            transition: background 0.2s;
        }
        .checkbox-item:hover { background-color: var(--slot-bg); }
        .checkbox-item input[type="checkbox"] {
            margin-top: 4px;
            margin-right: 12px;
            width: 16px; height: 16px;
            cursor: pointer; accent-color: var(--primary-color);
        }
        .checkbox-item label { margin-bottom: 0; font-weight: 400; font-size: 14px; cursor: pointer; line-height: 1.5; flex: 1; }
        .select-all-wrap { border-bottom: 1px solid var(--border-color); padding-bottom: 10px; margin-bottom: 10px; font-weight: 600; }
        /* ---------------- */

        .theme-toggle {
            cursor: pointer; padding: 8px; border-radius: 50%;
            background: var(--slot-bg); border: 1px solid var(--border-color);
            color: var(--text-color); display: flex; align-items: center;
            justify-content: center; width: 35px; height: 35px; margin-right: 15px;
        }
        .theme-toggle img { width: 20px; height: 20px; object-fit: contain; }

        @media (max-width: 900px) { 
            .main-content-wrapper { margin-left: 0; width: 100%; } 
            .form-row { flex-direction: column; gap: 0; } 
            .page-header { flex-direction: column; gap: 15px; text-align: center; }
        }
    </style>
</head>
<body>
    <nav class="main-menu">
        <ul>
            <?php foreach ($menu_items as $key => $item): ?>
                <?php 
                    $isActive = ($key == 'fyp_project');
                    $hasActiveChild = false;
                    if (isset($item['sub_items'])) {
                        foreach ($item['sub_items'] as $sub_key => $sub) {
                            if ($sub_key == $current_page) { $hasActiveChild = true; break; }
                        }
                    }
                    $linkUrl = isset($item['link']) ? $item['link'] : "#";
                    if ($linkUrl !== "#") { $separator = (strpos($linkUrl, '?') !== false) ? '&' : '?'; $linkUrl .= $separator . "auth_user_id=" . urlencode($auth_user_id); }
                    $hasSubmenu = isset($item['sub_items']);
                ?>
                <li class="menu-item <?php echo $hasActiveChild ? 'open' : ''; ?>">
                    <a href="<?php echo $hasSubmenu ? 'javascript:void(0)' : $linkUrl; ?>" class="<?php echo $isActive ? 'active' : ''; ?>" <?php if ($hasSubmenu): ?>onclick="toggleSubmenu(this)"<?php endif; ?>>
                        <i class="fa <?php echo $item['icon']; ?> nav-icon"></i><span class="nav-text"><?php echo $item['name']; ?></span><?php if ($hasSubmenu): ?><i class="fa fa-chevron-down dropdown-arrow"></i><?php endif; ?>
                    </a>
                    <?php if ($hasSubmenu): ?>
                        <ul class="submenu">
                            <?php foreach ($item['sub_items'] as $sub_key => $sub_item): 
                                $subLinkUrl = isset($sub_item['link']) ? $sub_item['link'] : "#";
                                if ($subLinkUrl !== "#") { $separator = (strpos($subLinkUrl, '?') !== false) ? '&' : '?'; $subLinkUrl .= $separator . "auth_user_id=" . urlencode($auth_user_id); }
                            ?>
                                <li><a href="<?php echo $subLinkUrl; ?>" class="<?php echo ($sub_key == $current_page) ? 'active' : ''; ?>"><i class="fa <?php echo $sub_item['icon']; ?> nav-icon"></i><span class="nav-text"><?php echo $sub_item['name']; ?></span></a></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <ul class="logout"><li><a href="login.php"><i class="fa fa-power-off nav-icon"></i><span class="nav-text">Logout</span></a></li></ul>
    </nav>

    <div class="main-content-wrapper">
        <div class="page-header">
            <div class="welcome-text"><h1>Propose New Assignment</h1><p>Create a task or assignment for your supervised students.</p></div>
            <div class="logo-section"><img src="image/ladybug.png" alt="Logo" class="logo-img"><span class="system-title">FYP Portal</span></div>
            <div class="user-section">
                <button class="theme-toggle" onclick="toggleDarkMode()" title="Toggle Dark Mode">
                    <img id="theme-icon" src="image/moon-solid-full.svg" alt="Toggle Theme">
                </button>
                <span class="user-badge">Supervisor</span>
                <?php if(!empty($user_avatar) && $user_avatar != 'image/user.png'): ?>
                    <img src="<?php echo htmlspecialchars($user_avatar); ?>" class="user-avatar" alt="User Avatar">
                <?php else: ?>
                    <div class="user-avatar-placeholder"><?php echo strtoupper(substr($user_name, 0, 1)); ?></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-card">
            <div class="section-title"><h2><i class="fa fa-tasks"></i> Assignment Details</h2></div>

            <div class="info-note">
                <i class="fa fa-info-circle"></i> 
                <strong>Assessment Category:</strong> Selecting a category will automatically set the recommended weightage.
            </div>
            
            <form id="assignForm" onsubmit="submitForm(event)">
                <input type="hidden" name="ajax_propose_assignment" value="true">
                <input type="hidden" name="auth_user_id" value="<?php echo $auth_user_id; ?>">
                
                <div class="form-group">
                    <label for="assessment_category">Assessment Category <span style="color:red">*</span></label>
                    <select id="assessment_category" class="form-control" onchange="autoFillWeightage(this.value)">
                        <option value="" disabled selected>-- Select Category --</option>
                        <option value="Proposal_10">Project Proposal (10%)</option>
                        <option value="Interim_20">Interim / Progress Report (20%)</option>
                        <option value="Final_40">Final Report (40%)</option>
                        <option value="Presentation_30">Presentation (30%)</option>
                        <option value="Custom">Custom Assignment</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="assignment_title">Assignment Title <span style="color:red">*</span></label>
                    <input type="text" id="assignment_title" name="assignment_title" class="form-control" placeholder="Enter assignment title (e.g. Chapter 1 Draft)" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="assignment_type">Target Type <span style="color:red">*</span></label>
                        <select id="assignment_type" name="assignment_type" class="form-control" onchange="toggleTargetList(this.value)">
                            <option value="" disabled selected>-- Select Type --</option>
                            <option value="Individual">Individual Students</option>
                            <option value="Group">Group Project</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="weightage">Weightage (%) <span style="color:red">*</span></label>
                        <input type="number" id="weightage" name="weightage" class="form-control" placeholder="0-100" min="0" max="100" required readonly style="background-color:var(--slot-bg);">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="deadline">Deadline <span style="color:red">*</span></label>
                    <input type="datetime-local" id="deadline" name="deadline" class="form-control" required>
                </div>
                
                <div id="target_container" class="target-select-container">
                    <label style="font-size:13px; font-weight:600; color:var(--text-secondary); margin-bottom:5px; display:block;">
                        Select Specific Targets <span style="color:red">*</span>
                    </label>
                    <div class="checkbox-group-container" id="target_checkbox_area">
                        </div>
                </div>

                <div class="form-group" style="margin-top:20px;">
                    <label for="assignment_description">Description / Instructions <span style="color:red">*</span></label>
                    <textarea id="assignment_description" name="assignment_description" class="form-control" placeholder="Describe the task requirements..." required></textarea>
                </div>

                <button type="submit" class="btn-submit" id="submitBtn"><i class="fa fa-paper-plane"></i> Publish Assignment</button>
            </form>
        </div>
    </div>

    <script>
        const myGroups = <?php echo json_encode($my_groups); ?>;
        const myIndividuals = <?php echo json_encode($my_individuals); ?>;

        function toggleSubmenu(element) {
            const menuItem = element.parentElement;
            const isOpen = menuItem.classList.contains('open');
            document.querySelectorAll('.menu-item').forEach(item => { if (item !== menuItem) item.classList.remove('open'); });
            if (isOpen) menuItem.classList.remove('open'); else menuItem.classList.add('open');
        }

        function autoFillWeightage(val) {
            const wInput = document.getElementById('weightage');
            const tInput = document.getElementById('assignment_title');
            
            if (val === 'Custom') {
                wInput.readOnly = false;
                wInput.style.backgroundColor = 'var(--card-bg)';
                wInput.value = '';
                wInput.focus();
            } else {
                const parts = val.split('_');
                const titleKey = parts[0];
                const weight = parts[1];
                
                wInput.readOnly = true;
                wInput.style.backgroundColor = 'var(--slot-bg)';
                wInput.value = weight;
                
                if (titleKey === 'Proposal') tInput.value = "Project Proposal Submission";
                else if (titleKey === 'Interim') tInput.value = "Interim / Progress Report";
                else if (titleKey === 'Final') tInput.value = "Final Report Submission";
                else if (titleKey === 'Presentation') tInput.value = "Presentation Slides / Materials";
            }
        }

        // --- 核心逻辑：动态生成多选框 ---
        function toggleTargetList(type) {
            const container = document.getElementById('target_container');
            const area = document.getElementById('target_checkbox_area');
            
            area.innerHTML = ''; // 清空内容
            container.style.display = 'block';
            
            let items = {};
            let emptyMsg = "";
            let labelPrefix = "";

            if (type === 'Group') {
                items = myGroups;
                emptyMsg = "No active groups found.";
                labelPrefix = "Group: ";
            } else if (type === 'Individual') {
                items = myIndividuals;
                emptyMsg = "No active individual students found.";
                labelPrefix = "Student: ";
            } else {
                container.style.display = 'none';
                return;
            }

            // 检查是否为空
            if (Object.keys(items).length === 0) {
                area.innerHTML = `<div style="padding:5px; color:var(--text-secondary);">${emptyMsg}</div>`;
                return;
            }

            // 1. 添加 "Select All"
            const selectAllDiv = document.createElement('div');
            selectAllDiv.className = 'checkbox-item select-all-wrap';
            selectAllDiv.innerHTML = `
                <input type="checkbox" id="selectAll" onchange="toggleSelectAll(this)">
                <label for="selectAll"><b>Select All</b></label>
            `;
            area.appendChild(selectAllDiv);

            // 2. 循环添加每一项
            for (const [id, name] of Object.entries(items)) {
                const div = document.createElement('div');
                div.className = 'checkbox-item';
                // name="target_selection[]" 确保 PHP 接收到的是数组
                div.innerHTML = `
                    <input type="checkbox" name="target_selection[]" class="target-checkbox" id="tgt_${id}" value="${id}">
                    <label for="tgt_${id}">${labelPrefix}${name}</label>
                `;
                area.appendChild(div);
            }
        }

        function toggleSelectAll(source) {
            const checkboxes = document.querySelectorAll('.target-checkbox');
            checkboxes.forEach(cb => {
                cb.checked = source.checked;
            });
        }

        function submitForm(event) {
            event.preventDefault();
            const btn = document.getElementById('submitBtn');
            btn.classList.add('loading');
            btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Publishing...';

            // FormData 自动支持 checkbox array
            const formData = new FormData(document.getElementById('assignForm'));

            fetch('supervisor_assignment_purpose.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    Swal.fire({
                        title: "Success!",
                        text: data.message,
                        icon: "success",
                        confirmButtonColor: "#28a745",
                        draggable: true
                    }).then(() => {
                        window.location.reload(); 
                    });
                    document.getElementById('assignForm').reset();
                    document.getElementById('target_container').style.display = 'none';
                } else {
                    Swal.fire("Error", data.message, "error");
                }
                btn.classList.remove('loading');
                btn.innerHTML = '<i class="fa fa-paper-plane"></i> Publish Assignment';
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire("Error", "An unexpected error occurred.", "error");
                btn.classList.remove('loading');
                btn.innerHTML = '<i class="fa fa-paper-plane"></i> Publish Assignment';
            });
        }

        function toggleDarkMode() {
            document.body.classList.toggle('dark-mode');
            const isDark = document.body.classList.contains('dark-mode');
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            
            const iconImg = document.getElementById('theme-icon');
            if (isDark) {
                iconImg.src = 'image/sun-solid-full.svg'; 
            } else {
                iconImg.src = 'image/moon-solid-full.svg'; 
            }
        }

        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.body.classList.add('dark-mode');
            const iconImg = document.getElementById('theme-icon');
            if(iconImg) {
                iconImg.src = 'image/sun-solid-full.svg'; 
            }
        }
    </script>
</body>
</html>